package org.zerock.myapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudySpringSecurityAppTests {

	@Test
	void contextLoads() {
	}

}
