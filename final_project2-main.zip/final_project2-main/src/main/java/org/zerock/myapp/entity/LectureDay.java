package org.zerock.myapp.entity;

public enum LectureDay {
	MON, THE, WEN, THU, FRI, SAT, SUN
} // end enum
